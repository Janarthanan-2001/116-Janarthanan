package com.marticus.em;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmpMgApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmpMgApplication.class, args);
	}

}
